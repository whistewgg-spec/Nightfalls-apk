const { contextBridge, ipcRenderer: ipc } = require('electron');
contextBridge.exposeInMainWorld('nf', {
  invoke: (c, d) => ipc.invoke(c, d),
  on: (c, f) => ipc.on(c, (_, d) => f(d))
});
