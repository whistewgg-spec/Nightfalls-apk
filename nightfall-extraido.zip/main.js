const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('path'), fs = require('fs'), crypto = require('crypto');
const { Client, Authenticator } = require('minecraft-launcher-core');
const { Auth } = require('msmc');
const extract = require('extract-zip'), os = require('os');
const { execFile } = require('child_process');

// ===== Configuração do projeto (edite aqui) =====
const SERVER = { host: 'nightfallgg.seedloaf.gg', port: 53320 };
const MC = '1.20.1', FORGE = '47.4.28';
const MANIFEST_URL = process.env.NIGHTFALL_MANIFEST || ''; // opcional: URL de um manifest.json online; vazio = usa o manifest.json embutido
const FORGE_URL = `https://maven.minecraftforge.net/net/minecraftforge/forge/${MC}-${FORGE}/forge-${MC}-${FORGE}-installer.jar`;

const cfgFile = path.join(app.getPath('userData'), 'config.json');
const defaults = { ram: 4096, width: 1280, height: 720, fullscreen: false, jvm: '', root: path.join(app.getPath('appData'), '.nightfall'), lang: 'pt-BR', installed: null, mode: 'microsoft', nick: '' };
const loadCfg = () => { try { return { ...defaults, ...JSON.parse(fs.readFileSync(cfgFile, 'utf8')) }; } catch { return { ...defaults }; } };
const saveCfg = c => { fs.mkdirSync(path.dirname(cfgFile), { recursive: true }); fs.writeFileSync(cfgFile, JSON.stringify(c, null, 2)); };

let win;
const send = (ch, d) => win && !win.isDestroyed() && win.webContents.send(ch, d);
const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');

async function download(url, dest, expected, label) {
  if (fs.existsSync(dest) && (!expected || sha(dest) === expected)) return false; // já atualizado
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  const r = await fetch(url); if (!r.ok) throw new Error(`Falha ao baixar ${label} (HTTP ${r.status})`);
  const total = +r.headers.get('content-length') || 0, chunks = []; let got = 0;
  for await (const c of r.body) { chunks.push(c); got += c.length; send('progress', { label, pct: total ? got / total * 100 : null }); }
  const buf = Buffer.concat(chunks);
  if (expected && crypto.createHash('sha256').update(buf).digest('hex') !== expected) throw new Error(`Arquivo corrompido: ${label} (SHA-256 não confere)`);
  fs.writeFileSync(dest, buf); return true;
}
const allowedHost = u => ['maven.minecraftforge.net', ...(JSON.parse(process.env.NIGHTFALL_HOSTS || '[]'))].includes(new URL(u).host)  || new URL(u).host.endsWith('cdn.modrinth.com') || new URL(u).host.endsWith('mediafire.com');

async function getManifest() {
  if (MANIFEST_URL) { try { const r = await fetch(MANIFEST_URL, { signal: AbortSignal.timeout(8000) }); if (r.ok) return await r.json(); } catch {} }
  return JSON.parse(fs.readFileSync(path.join(__dirname, 'manifest.json'), 'utf8')); // manifesto embutido
}


const okFile = (f, h) => fs.existsSync(f) && sha(f) === h;
async function mediafireLink(page) {
  const html = await (await fetch(page, { headers: { 'user-agent': 'Mozilla/5.0' } })).text();
  const sc = html.match(/data-scrambled-url="([^"]+)"/);
  if (sc) return Buffer.from(sc[1], 'base64').toString();
  const m = html.match(/https:\/\/download\d*\.mediafire\.com\/[^"'\s<>]+/);
  if (!m) throw new Error('Não foi possível obter o link de download do MediaFire.');
  return m[0];
}
async function downloadToDisk(url, dest, label) { // em disco, para arquivos grandes
  const r = await fetch(url, { headers: { 'user-agent': 'Mozilla/5.0' } });
  if (!r.ok || /text\/html/.test(r.headers.get('content-type') || '')) throw new Error(`Falha ao baixar ${label}. O link pode ter expirado.`);
  const total = +r.headers.get('content-length') || 0; let got = 0;
  const out = fs.createWriteStream(dest);
  for await (const c of r.body) { got += c.length; if (!out.write(c)) await new Promise(ok => out.once('drain', ok)); send('progress', { label, pct: total ? got / total * 100 : null }); }
  await new Promise(ok => out.end(ok));
}
async function syncFromPack(m, modsDir) { // baixa o zip do modpack e aproveita só os mods do manifesto (casados por SHA-256)
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'nightfall-'));
  try {
    send('stage', 'Baixando o modpack…');
    const zip = path.join(tmp, 'pack.zip'); await downloadToDisk(await mediafireLink(m.pack.page), zip, 'Modpack NIGHTFALL');
    send('stage', 'Extraindo mods…'); const dir = path.join(tmp, 'x'); await extract(zip, { dir });
    const want = new Map(m.mods.map(x => [x.sha256, x.file])); const found = new Set();
    const walk = d => fs.readdirSync(d, { withFileTypes: true }).forEach(e => {
      const p = path.join(d, e.name); if (e.isDirectory()) return walk(p);
      if (!e.name.endsWith('.jar')) return; const h = sha(p);
      if (want.has(h)) { fs.copyFileSync(p, path.join(modsDir, want.get(h))); found.add(h); } });
    walk(dir);
    const miss = m.mods.filter(x => !found.has(x.sha256)).map(x => x.file);
    if (miss.length) throw new Error('Mods ausentes ou diferentes no pacote: ' + miss.join(', '));
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
}

async function sync(cfg) {
  const m = await getManifest();
  if (m.minecraft !== MC || m.forge !== FORGE) throw new Error(`Manifesto incompatível (esperado MC ${MC} / Forge ${FORGE}).`);
  const modsDir = path.join(cfg.root, 'mods'); fs.mkdirSync(modsDir, { recursive: true });
  const forgeJar = path.join(cfg.root, 'forge', path.basename(FORGE_URL));
  await download(FORGE_URL, forgeJar, null, 'Forge ' + FORGE);

  // 1. Auto-instala mods embutidos localmente no launcher (ex: expansão Bloodlines final)
  const bundledMods = new Set();
  const bundledDir = path.join(__dirname, 'bundled_mods');
  if (fs.existsSync(bundledDir)) {
    for (const b of fs.readdirSync(bundledDir)) {
      if (b.endsWith('.jar')) {
        const srcP = path.join(bundledDir, b);
        const dstP = path.join(modsDir, b);
        if (!fs.existsSync(dstP) || fs.statSync(srcP).size !== fs.statSync(dstP).size) {
          fs.copyFileSync(srcP, dstP);
        }
        bundledMods.add(b);
      }
    }
  }

  // 2. Filtra os mods remotos do pack que precisam de download
  const netMods = (m.mods || []).filter(x => !bundledMods.has(x.file));
  const keep = new Set([...(m.mods || []).map(x => x.file), ...bundledMods]);

  if (m.pack && !netMods.every(x => okFile(path.join(modsDir, x.file), x.sha256))) {
    await syncFromPack({ ...m, mods: netMods }, modsDir);
  } else if (!m.pack) {
    for (const mod of netMods) {
      if (!allowedHost(mod.url)) throw new Error(`Origem não permitida para ${mod.file}`);
      await download(mod.url, path.join(modsDir, mod.file), mod.sha256, mod.file);
    }
  }

  for (const f of fs.readdirSync(modsDir)) {
    if (f.endsWith('.jar') && !keep.has(f)) {
      try { fs.unlinkSync(path.join(modsDir, f)); } catch {}
    }
  }
  cfg.installed = m.version; saveCfg(cfg); return { forgeJar, manifest: m };
}

ipcMain.handle('cfg:get', () => loadCfg());
ipcMain.handle('cfg:set', (_, c) => { saveCfg({ ...loadCfg(), ...c }); return true; });
ipcMain.handle('server:status', async () => {
  try { const j = await (await fetch(`https://api.mcsrvstat.us/3/${SERVER.host}:${SERVER.port}`)).json();
    return { online: !!j.online, players: j.players?.online ?? 0, max: j.players?.max ?? 0, ...SERVER, mc: MC, forge: FORGE }; }
  catch { return { online: false, players: 0, max: 0, ...SERVER, mc: MC, forge: FORGE }; }
});
ipcMain.handle('pack:info', async () => { try { return await getManifest(); } catch (e) { return { error: e.message }; } });
ipcMain.handle('pack:repair', async () => { try { const c = loadCfg(); fs.rmSync(path.join(c.root, 'mods'), { recursive: true, force: true }); await sync(c); return { ok: true }; } catch (e) { return { error: e.message }; } });
ipcMain.handle('voice:check', () => {
  const d = path.join(loadCfg().root, 'mods'); const f = fs.existsSync(d) ? fs.readdirSync(d).map(x => x.toLowerCase()) : [];
  return { plasmo: f.some(x => x.includes('plasmovoice')), svc: f.some(x => x.includes('voicechat')) };
});
ipcMain.handle('open:mods', () => { const d = path.join(loadCfg().root, 'mods'); fs.mkdirSync(d, { recursive: true }); return shell.openPath(d); });

// ===== Java 17 embutido (o Minecraft 1.20.1 + Forge 47 exige Java 17) =====
const javaExe = d => path.join(d, 'bin', 'java.exe');
function findJavaIn(dir) {
  if (!fs.existsSync(dir)) return null;
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    if (e.isDirectory()) { const j = javaExe(path.join(dir, e.name)); if (fs.existsSync(j)) return j; }
  }
  return null;
}
const javaMajor = p => new Promise(res => execFile(p, ['-version'], { windowsHide: true, timeout: 15000 }, (err, so, se) => {
  const m = /version "(\d+)(?:\.(\d+))?/.exec(String(se || so || ''));
  res(err || !m ? 0 : (m[1] === '1' ? +m[2] : +m[1]));
}));
async function ensureJava(root) {
  const rt = path.join(root, 'runtime', 'java17');
  let j = findJavaIn(rt);
  if (j && await javaMajor(j) === 17) return j;
  try {
    send('stage', 'Baixando o Java 17 (só na primeira vez)…');
    const meta = await (await fetch('https://api.adoptium.net/v3/assets/latest/17/hotspot?architecture=x64&image_type=jre&os=windows&vendor=eclipse', { signal: AbortSignal.timeout(20000) })).json();
    const pkg = (meta || []).map(x => x.binary && x.binary.package).find(p => p && /\.zip$/.test(p.name));
    if (!pkg) throw new Error('pacote do Java não encontrado');
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'nightfall-java-'));
    try {
      const zip = path.join(tmp, pkg.name);
      await downloadToDisk(pkg.link, zip, 'Java 17');
      if (pkg.checksum && sha(zip) !== pkg.checksum) throw new Error('Java 17 corrompido (SHA-256 não confere)');
      fs.rmSync(rt, { recursive: true, force: true }); fs.mkdirSync(rt, { recursive: true });
      send('stage', 'Instalando o Java 17…'); await extract(zip, { dir: rt });
    } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
    j = findJavaIn(rt);
    if (j && await javaMajor(j) === 17) return j;
    throw new Error('o Java 17 baixado não executou');
  } catch (e) {
    const sys = await javaMajor('java'); // plano B: Java do sistema, se for compatível
    if (sys >= 17 && sys <= 21) return 'java';
    throw new Error('Não foi possível preparar o Java 17 (' + e.message + '). Verifique a internet/antivírus ou instale o Java 17 (Temurin) manualmente.');
  }
}

ipcMain.handle('open:logs', () => shell.openPath(loadCfg().root));

ipcMain.handle('play', async () => {
  try {
    const cfg = loadCfg(); send('stage', 'Verificando arquivos…');
    fs.mkdirSync(cfg.root, { recursive: true });
    const { forgeJar } = await sync(cfg);
    const javaPath = await ensureJava(cfg.root);
    let token;
    if (cfg.mode === 'offline') {
      if (!/^[A-Za-z0-9_]{3,16}$/.test(cfg.nick || '')) throw new Error('Nick inválido. Use 3 a 16 letras, números ou _.');
      token = await Authenticator.getAuth(cfg.nick); // modo offline: só funciona em servidor com online-mode=false
    } else {
      send('stage', 'Entrando com a conta Microsoft…');
      const auth = new Auth('select_account'); const xbox = await auth.launch('electron'); token = (await xbox.getMinecraft()).mclc(); // tokens ficam só em memória
    }

    // RAM: nunca pedir mais do que o PC aguenta (senão o Java fecha na hora)
    const totalMb = Math.floor(os.totalmem() / 1048576);
    const maxMb = Math.max(2048, Math.min(+cfg.ram || 4096, totalMb - 1536));
    const minMb = Math.min(1024, maxMb);

    const logFile = path.join(cfg.root, 'launcher.log'), tail = [];
    fs.writeFileSync(logFile, `NIGHTFALL ${new Date().toISOString()}\nJava: ${javaPath}\nRAM total: ${totalMb} MB | Xmx: ${maxMb} MB\n\n`);
    const log = t => { t = String(t); try { fs.appendFileSync(logFile, t.endsWith('\n') ? t : t + '\n'); } catch {} tail.push(...t.split(/\r?\n/).filter(Boolean)); if (tail.length > 40) tail.splice(0, tail.length - 40); send('log', t); };

    const launcher = new Client();
    let started = false;
    launcher.on('progress', e => send('progress', { label: e.type, pct: e.total ? e.task / e.total * 100 : null }));
    launcher.on('debug', e => log(e)); launcher.on('data', e => log(e));
    launcher.on('close', code => {
      if (!started) return; // falha de inicialização já é devolvida pelo retorno do launch
      if (code === 0 || code === null) return send('stage', 'Jogo encerrado.');
      const crash = path.join(cfg.root, 'crash-reports');
      send('stage', `O jogo fechou com erro (código ${code}). Veja o log em ${logFile}` + (fs.existsSync(crash) ? ` e a pasta crash-reports.` : '.'));
      send('log', '--- últimas linhas ---\n' + tail.join('\n'));
    });

    send('stage', 'Instalando e iniciando Minecraft…');
    const proc = await launcher.launch({
      authorization: token, root: cfg.root, forge: forgeJar, javaPath,
      version: { number: MC, type: 'release' }, memory: { max: maxMb + 'M', min: minMb + 'M' },
      customArgs: cfg.jvm ? cfg.jvm.split(/\s+/).filter(Boolean) : [],
      window: cfg.fullscreen ? { fullscreen: true } : { width: cfg.width, height: cfg.height },
      server: { host: SERVER.host, port: String(SERVER.port) }
    });
    if (!proc) throw new Error('Não foi possível iniciar o Minecraft. Veja o log em ' + logFile + '\n' + tail.slice(-5).join('\n'));
    started = true;
    return { ok: true };
  } catch (e) { return { error: e.message || String(e) }; }
});

app.whenReady().then(() => {
  win = new BrowserWindow({ width: 1100, height: 680, minWidth: 900, minHeight: 600, frame: true, backgroundColor: '#0a0707', autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false } });
  win.webContents.session.setPermissionRequestHandler((_, p, cb) => cb(p === 'media')); // só microfone (teste de voz)
  win.loadFile('src/index.html');
});
app.on('window-all-closed', () => app.quit());
